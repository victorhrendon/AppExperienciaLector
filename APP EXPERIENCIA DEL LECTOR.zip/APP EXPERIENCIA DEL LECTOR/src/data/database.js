const mysql = require('mysql');
const {promisify} = require('util');
const {database} = require('../kekys');

const pool = mysql.createPool(database);
console.log('los datos de la BD son: ', database)

pool.getConnection((err, connection) => {
    if(err != null){
        if(err.code === 'PROTOCOL_CONNECTION_LOST'){
            console.log('La conexion con la base de datos fue cerrada');
        };
        if(err.code === 'ER_CON_COUNT_ERROR'){
            console.log('La base de datos tiene muchas conexiones');
        };
        if(err.code === 'ECONNREFUSED'){
            console.log('La conexion fue rechazada');
        };
    }
    
    if(connection) connection.release();
    console.log('Base de datos conectada');
    return;
});

pool.query = promisify(pool.query);

module.exports = pool;