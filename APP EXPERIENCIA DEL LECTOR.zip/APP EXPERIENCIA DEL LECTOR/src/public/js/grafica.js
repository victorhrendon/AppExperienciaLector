var ctx = document.getElementById('myChart').getContext('2d');
var tabla = []

function NombresPublicaciones(){
    var miArray=new Array()
    var i=0
    var tabla = document.getElementById("datos");
    var total=tabla.rows.length
    
    for(j=0;j<=total-1;j++){
        var dato=tabla.rows[j].cells[0].childNodes[0].nodeValue
        miArray[i]=dato
        i=i+1
    }

    miArray.reverse();
    var miArrayNuevo=new Array()
    for(i=0; i < 20 && i < miArray.length; i++){
        miArrayNuevo[i] = miArray[i].substring(0,15);
    }

    return miArrayNuevo.reverse();
}

function ReaccionesPublicaciones(){
    var miArray=new Array()
    var i=0
    var tabla = document.getElementById("datos");
    var total=tabla.rows.length
    
    for(j=0;j<=total-1;j++){
        var dato=tabla.rows[j].cells[2].childNodes[0].nodeValue
        miArray[i]=dato
        i=i+1
    }
    
    miArray.reverse();
    var miArrayNuevo=new Array()
    for(i=0; i < 20 && i < miArray.length; i++){
        miArrayNuevo[i] = miArray[i];
    }
    return miArrayNuevo.reverse();
}

function ComentariosPublicaciones(){
    var miArray=new Array()
    var i=0
    var tabla = document.getElementById("datos");
    var total=tabla.rows.length
    
    for(j=0;j<=total-1;j++){
        var dato=tabla.rows[j].cells[3].childNodes[0].nodeValue
        miArray[i]=dato
        i=i+1
    }
    miArray.reverse();
    var miArrayNuevo=new Array()
    for(i=0; i < 20 && i < miArray.length; i++){
        miArrayNuevo[i] = miArray[i];
    }

    return miArrayNuevo.reverse();
}

function CompartidoPublicaciones(){
    var miArray=new Array()
    var i=0
    var tabla = document.getElementById("datos");
    var total=tabla.rows.length
    
    for(j=0;j<=total-1;j++){
        var dato=tabla.rows[j].cells[4].childNodes[0].nodeValue
        miArray[i]=dato
        i=i+1
    }
    miArray.reverse();
    var miArrayNuevo=new Array()
    for(i=0; i < 20 && i < miArray.length; i++){
        miArrayNuevo[i] = miArray[i];
    }

    return miArrayNuevo.reverse();
}

function TiempoPublicaciones(){
    var miArray=new Array()
    var i=0
    var tabla = document.getElementById("datos");
    var total=tabla.rows.length
    
    for(j=0;j<=total-1;j++){
        var dato=tabla.rows[j].cells[5].childNodes[0].nodeValue
        miArray[i]=dato
        i=i+1
    }
    miArray.reverse();
    var miArrayNuevo=new Array()
    for(i=0; i < 20 && i < miArray.length; i++){
        miArrayNuevo[i] = miArray[i];
    }

    return miArrayNuevo.reverse();
}

var myChart = new Chart(ctx, {
    
    type: 'line',
    data: {
        labels: NombresPublicaciones(),
        datasets: [{
            label: 'Reacciones',
            data: ReaccionesPublicaciones(),
            backgroundColor: [
                'rgba(255, 99, 132, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(75, 192, 192, 0.2)',
                'rgba(153, 102, 255, 0.2)',
                'rgba(255, 159, 64, 0.2)'
            ],
            borderColor: [
                'rgba(255, 99, 132, 1)',
                'rgba(54, 162, 235, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)',
                'rgba(153, 102, 255, 1)',
                'rgba(255, 159, 64, 1)'
            ],
            borderWidth: 1
        },
        {
            label: 'Comentarios',
            data: ComentariosPublicaciones(),
            backgroundColor: [
                'rgba(255, 99, 132, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(75, 192, 192, 0.2)',
                'rgba(153, 102, 255, 0.2)',
                'rgba(255, 159, 64, 0.2)'
            ],
            borderColor: [
                'rgba(255, 99, 132, 1)',
                'rgba(54, 162, 235, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)',
                'rgba(153, 102, 255, 1)',
                'rgba(255, 159, 64, 1)'
            ],
            borderWidth: 1
        },
        {
            label: 'Compartido',
            data: CompartidoPublicaciones(),
            backgroundColor: [
                'rgba(255, 99, 132, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(75, 192, 192, 0.2)',
                'rgba(153, 102, 255, 0.2)',
                'rgba(255, 159, 64, 0.2)'
            ],
            borderColor: [
                'rgba(255, 99, 132, 1)',
                'rgba(54, 162, 235, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)',
                'rgba(153, 102, 255, 1)',
                'rgba(255, 159, 64, 1)'
            ],
            borderWidth: 1
        },
        {
            label: 'Tiempo',
            data: TiempoPublicaciones(),
            backgroundColor: [
                'rgba(255, 99, 132, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(75, 192, 192, 0.2)',
                'rgba(153, 102, 255, 0.2)',
                'rgba(255, 159, 64, 0.2)'
            ],
            borderColor: [
                'rgba(255, 99, 132, 1)',
                'rgba(54, 162, 235, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)',
                'rgba(153, 102, 255, 1)',
                'rgba(255, 159, 64, 1)'
            ],
            borderWidth: 1
        },
    
        ]
    },
    options: {
        responsive: true,
        plugins: {
            title: {
                display: true,
                text: 'Experiencia de los lectores'
            }
        },
        scales: {
            x: {
              display: true,
              title: {
                display: true,
                text: 'Contenidos Publicados',
                color: 'rgb(85, 85, 85)',
                font: {
                    family: 'Tahoma',
                    size: 15,
                    style: 'normal',
                    lineHeight: 1.2
                },
                padding: {top: 20, left: 0, right: 0, bottom: 0}
              }
            },
            y: {
              display: true,
              title: {
                display: true,
                text: 'Variables para medir la experiencia del lector',
                color: 'rgb(85, 85, 85)',
                font: {
                  family: 'Tahoma',
                  size: 15,
                  style: 'normal',
                  lineHeight: 1.2
                },
                padding: {top: 20, left: 0, right: 0, bottom: 0}
              }
            }
        },
    }
});
