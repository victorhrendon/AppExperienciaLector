const express = require("express");
const router = express.Router();
const pool = require("../data/database");
const chart = require("chart.js");
const jsdom = require("jsdom");
const { JSDOM } = jsdom;
const variablesDao = {};

variablesDao.estadisticas = async (req, res) => {
    const nombresContenidos = await pool.query("SELECT NombreP FROM contenido");
    const reacciones = await pool.query(
      "SELECT reacciones FROM variable INNE JOIN contenido USING (IdP)"
    );
    const comentarios = await pool.query(
      "SELECT comentarios FROM variable INNE JOIN contenido USING (IdP)"
    );
    const compartido = await pool.query(
      "SELECT compartido FROM variable INNE JOIN contenido USING (IdP)"
    );
    const tiempo = await pool.query(
      "SELECT tiempo FROM variable INNE JOIN contenido USING (IdP)"
    );
  
    const arrayNombres = [];
    const arrayReacciones = [];
    const arrayComentarios = [];
    const arrayCompartidos = [];
    const arrayTiempos = [];
    for (var i = 0; i < nombresContenidos.length; i++) {
      arrayNombres.push(nombresContenidos[i].NombreP);
      arrayReacciones.push(reacciones[i].reacciones);
      arrayComentarios.push(comentarios[i].comentarios);
      arrayCompartidos.push(compartido[i].compartido);
      arrayTiempos.push(tiempo[i].tiempo);
    }
  
    const parametro = [];
    parametro.push(
      arrayNombres,
      arrayReacciones,
      arrayComentarios,
      arrayCompartidos,
      arrayTiempos
    );
    console.log("PARAMETRO = ", parametro);
    return parametro;
};


variablesDao.estadisticaGet = async (req, res) => {
  const nombresContenidos = await pool.query("SELECT NombreP FROM contenido");
  const reacciones = await pool.query(
    "SELECT reacciones FROM variable INNE JOIN contenido USING (IdP)"
  );
  const comentarios = await pool.query(
    "SELECT comentarios FROM variable INNE JOIN contenido USING (IdP)"
  );
  const compartido = await pool.query(
    "SELECT compartido FROM variable INNE JOIN contenido USING (IdP)"
  );
  const tiempo = await pool.query(
    "SELECT tiempo FROM variable INNE JOIN contenido USING (IdP)"
  );

  const arrayNombres = [];
  const arrayReacciones = [];
  const arrayComentarios = [];
  const arrayCompartidos = [];
  const arrayTiempos = [];
  for (var i = 0; i < nombresContenidos.length; i++) {
    arrayNombres.push(nombresContenidos[i].NombreP);
    arrayReacciones.push(reacciones[i].reacciones);
    arrayComentarios.push(comentarios[i].comentarios);
    arrayCompartidos.push(compartido[i].compartido);
    arrayTiempos.push(tiempo[i].tiempo);
  }

  const parametro = [];
  parametro.push(
    arrayNombres,
    arrayReacciones,
    arrayComentarios,
    arrayCompartidos,
    arrayTiempos
  );
  console.log("PARAMETRO = ", parametro);

  const contenidos = await pool.query('SELECT * FROM contenido C JOIN variable V ON C.IdP = V.IdP');
  res.render('contenidos/estadistica', {contenidos});
};

module.exports = variablesDao;
