const express = require('express');
const router = express.Router();
const pool = require('../data/database');
const contenidoDao = {};

contenidoDao.addGet = (req, res)=>{
    res.render('contenidos/add');
}

contenidoDao.add = async (req, res) =>{
    const {nombreP, categoriaP} = req.body;
    const {reacciones, comentarios, compartido, tiempo} = req.body;
    const infoContenido = {
        nombreP,
        categoriaP
    };
    
    const resultado = await pool.query('INSERT INTO contenido set ?', [infoContenido]);
    const IdP = resultado.insertId;
    console.log(IdP)
    const infoVariables = {
        IdP,
        reacciones,
        comentarios,
        compartido,
        tiempo
    };
    console.log('Variables = ', infoVariables)
    await pool.query('INSERT INTO variable set ?', [infoVariables]);
    req.flash('success', 'Contenido agregado correctamente');
    res.redirect('/');
};

contenidoDao.listar = async (req, res) => {
    const contenidos = await pool.query('SELECT * FROM contenido ORDER BY fechaRegistroP DESC');
    res.render('contenidos/list', {contenidos});
};

contenidoDao.eliminar = async (req, res) =>{
    const { id } = req.params;
    await pool.query('DELETE FROM contenido WHERE IdP = ?', [id]);
    req.flash('success', 'Contenido eliminado correctamente');
    res.redirect('/');
}

contenidoDao.editarGet = async (req, res) =>{
    const { id } = req.params;
    const contenido = await pool.query('SELECT * FROM contenido WHERE IdP = ?',[id]);
    const varibles = await pool.query('SELECT * FROM variable WHERE IdP = ?',[id]);
    
    const parametro = {
        IdP: contenido[0].IdP,
        NombreP: contenido[0].NombreP,
        CategoriaP: contenido[0].CategoriaP,
        reacciones: varibles[0].reacciones,
        comentarios: varibles[0].comentarios,
        compartido: varibles[0].compartido,
        tiempo: varibles[0].tiempo
    }
    console.log(parametro)

    res.render('contenidos/editar', {contenido: parametro});
}

contenidoDao.editar = async (req, res) =>{
    const { id } = req.params;
    const {nombreP, categoriaP} = req.body;
    const {reacciones, comentarios, compartido, tiempo} = req.body;
    const infoContenidoActualizado = {
        nombreP,
        categoriaP
    };
    await pool.query('UPDATE contenido set ? WHERE IdP = ?', [infoContenidoActualizado, id]);
    const infoVariablesAcualizado = {
        reacciones,
        comentarios,
        compartido,
        tiempo
    };
    console.log(infoVariablesAcualizado);
    
    await pool.query('UPDATE variable set ? WHERE IdP = ?', [infoVariablesAcualizado, id]);
    req.flash('success', 'Contenido actualizado correctamente');
    res.redirect('/');
}

module.exports = contenidoDao;