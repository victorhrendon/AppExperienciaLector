const contenidoDAO = require('../dao/contenidoDao');
const variablesDAO = require('../dao/variablesDao')

const controller = {};

controller.list = contenidoDAO.listar

controller.add = contenidoDAO.add

controller.addGet = contenidoDAO.addGet

controller.listar = contenidoDAO.listar

controller.eliminar = contenidoDAO.eliminar

controller.editar = contenidoDAO.editar

controller.editarGet = contenidoDAO.editarGet

controller.estadisticaGet = variablesDAO.estadisticaGet

module.exports = controller;
