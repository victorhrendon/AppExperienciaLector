const express = require('express');
const router = express.Router();
const pool = require('../data/database');
const customerContrller = require('../controller/contenidoController');

router.get('/add',customerContrller.addGet);

router.post('/add', customerContrller.add);

router.get('/',customerContrller.listar);

router.get('/contenidos',customerContrller.listar);

router.get('/delete/:id', customerContrller.eliminar);

router.get('/editar/:id', customerContrller.editarGet);

router.post('/editar/:id', customerContrller.editar);

router.get('/estadistica', customerContrller.estadisticaGet);

module.exports = router;