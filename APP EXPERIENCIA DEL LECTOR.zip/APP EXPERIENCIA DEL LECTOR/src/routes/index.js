const express = require('express');
const router = express.Router();
const customerContrller = require('../controller/contenidoController');

router.get('/', customerContrller.list);

module.exports = router;
